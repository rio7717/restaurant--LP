export default function Page() {
  return (
    <main className="max-w-4xl mx-auto px-4 py-12">
      <section className="text-center space-y-4">
        <h1 className="text-3xl font-bold">選ばれる飲食ブランドには、理由がある。</h1>
        <p className="text-lg">食と人をつなぐ新・戦略論</p>
        <p className="text-xl font-semibold">ブランドが語る。お客様が動く。スタッフが誇る。</p>
        <p>飲食店の"らしさ"を言語化し、ビジネスの土台をつくる。</p>
      </section>
    </main>
  );
}
