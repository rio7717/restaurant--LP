# Restaurant LP

This is a simple restaurant landing page built with Next.js and Tailwind CSS.
